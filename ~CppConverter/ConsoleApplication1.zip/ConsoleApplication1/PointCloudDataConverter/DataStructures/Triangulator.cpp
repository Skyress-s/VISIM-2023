﻿#include "Triangulator.h"
